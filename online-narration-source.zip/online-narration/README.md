# Online narration source

This folder contains the sentence-highlighting scripts and timing data used by the [hosted reader](https://farmanne.com/reading/book/original.html). The offline reader in the repository root does not require these files.

The timed text uses the same attribution and CC BY-SA terms as the book in the repository root. This folder contains no MP3 files.

Each timing file is named for its corresponding narration track. In each cue, `p` is the zero-based paragraph number, `start` and `end` locate the text within the paragraph, and `time` and `stop` are seconds into the track. Cues are estimates. A sentence without a cue can still be heard during continuous playback.
