/* Shared by the two reader views. Explicit page links take priority over the bookmark. */
const readerAudio = (() => {
  const key = 'farmanne.guilin.reader.v1';
  const file = location.pathname.split('/').pop();
  let saved;
  try { saved = JSON.parse(localStorage.getItem(key)); } catch {}
  const valid = saved && ['original.html', 'chapters.html'].includes(saved.file) &&
    (saved.file === 'original.html' ? /^#page-\d+$/ : /^#chapter-\d+-page-\d+$/).test(saved.page);
  const redirect = valid && !location.hash && saved.file !== file;
  if (redirect) location.replace(saved.file + saved.page);
  else if (valid && !location.hash) history.replaceState(null, '', saved.page);

  let current;
  let page;
  let lang;
  let pendingTime = 0;
  let initial = true;
  let opened = false;
  let source;
  let blobUrl;
  let download;
  let playAfterSeek = false;
  async function seek(seconds) {
    const track = current;
    const signal = listeners.signal;
    pendingTime = seconds;
    save();
    if (!seconds || blobUrl || (track.seekable.length && track.seekable.end(track.seekable.length - 1) >= seconds)) {
      track.currentTime = seconds;
      pendingTime = 0;
      draw();
      return;
    }
    if (download) return;
    playAfterSeek = !track.paused;
    try {
      download = fetch(source, {signal});
      const response = await download;
      if (!response.ok) throw new Error('Audio unavailable');
      const blob = await response.blob();
      if (signal.aborted) return;
      blobUrl = URL.createObjectURL(blob);
      track.preload = 'auto';
      track.src = blobUrl;
    } catch {
      if (!signal.aborted) {
        download = null;
        pendingTime = 0;
        draw();
      }
    }
  }
  const panel = document.createElement('div');
  panel.className = 'reader-seek';
  panel.hidden = true;
  const slider = document.createElement('input');
  slider.type = 'range';
  slider.min = 0;
  slider.step = 0.1;
  const label = document.createElement('span');
  panel.append(slider, label);
  function clock(s) {
    s = Math.floor(s || 0);
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }
  function draw() {
    const duration = Number.isFinite(current.duration) ? current.duration : 0;
    const time = pendingTime || current.currentTime;
    slider.disabled = !duration;
    slider.max = duration;
    slider.value = time;
    slider.setAttribute('aria-label', lang === 'en' ? 'Narration position' : '朗读进度');
    label.textContent = clock(time) + ' / ' + clock(duration);
    slider.setAttribute('aria-valuetext', label.textContent);
    panel.hidden = !opened;
  }
  function save() {
    if (!current || redirect) return;
    const time = current.ended ? 0 : pendingTime || current.currentTime;
    try { localStorage.setItem(key, JSON.stringify({file, page, lang, time})); } catch {}
  }
  slider.addEventListener('input', () => {
    seek(Number(slider.value));
  });
  window.addEventListener('pagehide', save);
  document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
  let listeners;
  function bind(track, nextPage, language, src) {
    if (redirect || (track === current && nextPage === page && language === lang)) return;
    const resume = current && !current.paused && !current.ended && lang === language;
    listeners?.abort();
    current?.pause();
    if (blobUrl) {
      current.src = source;
      URL.revokeObjectURL(blobUrl);
    }
    blobUrl = null;
    download = null;
    playAfterSeek = false;
    current = track;
    page = nextPage;
    lang = language;
    pendingTime = initial && valid && saved.file === file && saved.page === page &&
      saved.lang === lang && Number.isFinite(saved.time) ? Math.max(0, saved.time) : 0;
    opened = opened || pendingTime > 0;
    initial = false;
    if (src) track.src = src;
    source = track.src;
    window.readerSentences?.bind(track, page, lang, source, seek);
    listeners = new AbortController();
    const options = {signal: listeners.signal};
    function ready() {
      if (pendingTime && Number.isFinite(track.duration)) {
        seek(Math.min(pendingTime, track.duration));
      }
      if (blobUrl && playAfterSeek) {
        playAfterSeek = false;
        track.play().catch(() => draw());
      }
      draw();
    }
    track.addEventListener('loadedmetadata', ready, options);
    track.addEventListener('play', () => { opened = true; draw(); }, options);
    for (const event of ['timeupdate','pause','seeked','ended']) {
      track.addEventListener(event, () => { draw(); save(); }, options);
    }
    if (!pendingTime) track.currentTime = 0;
    if (pendingTime) track.preload = 'metadata';
    if (track.readyState >= 1) ready();
    if (!panel.isConnected) document.querySelector('.book-reader-header').append(panel);
    if (resume) {
      track.defaultPlaybackRate = track.playbackRate = lang === 'en' ? 0.85 : 0.75;
      track.play().catch(() => draw());
    }
    draw();
    save();
  }
  return {bind, language: valid && saved.lang === 'en' ? 'en' : 'zh'};
})();
