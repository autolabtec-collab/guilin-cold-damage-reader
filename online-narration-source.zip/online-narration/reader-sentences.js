(() => {
  if (!CSS.highlights) return;

  const highlight = new Highlight();
  CSS.highlights.set('spoken-sentence', highlight);
  let binding;
  let previousRange;

  function textPoint(paragraph, offset) {
    const walker = document.createTreeWalker(paragraph, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      if (offset <= node.length) return [node, offset];
      offset -= node.length;
    }
    return [paragraph, paragraph.childNodes.length];
  }

  function rangeFor(paragraph, cue) {
    const range = new Range();
    range.setStart(...textPoint(paragraph, cue.start));
    range.setEnd(...textPoint(paragraph, cue.end));
    return range;
  }

  function clear() {
    previousRange = undefined;
    highlight.clear();
  }

  function draw() {
    if (!binding) return;
    const {track, cues, started} = binding;
    if (!started || track.ended) return clear();
    const now = track.currentTime;
    const cue = cues.findLast(cue => cue.time <= now);
    const range = cue && now <= cue.stop ? cue.range : undefined;
    if (range === previousRange) return;
    clear();
    if (range) {
      highlight.add(range);
      previousRange = range;
    }
  }

  async function bind(track, page, lang, source, seek) {
    binding?.controller.abort();
    clear();
    document.body.classList.remove('sentence-playback');
    const controller = new AbortController();
    const id = new URL(source).pathname.split('/').pop().replace(/\.mp3$/, '');
    const section = document.getElementById(page.slice(1));
    const column = document.getElementById('chapter-text') ??
      section?.querySelector(lang === 'en' ? '.whole-page-english' : '.whole-page-original');
    const current = {track, lang, seek, controller, column, cues: [], started: !track.paused || track.currentTime > 0};
    binding = current;
    if (!column) return;
    const {signal} = controller;
    track.addEventListener('play', () => { current.started = true; draw(); }, {signal});
    for (const event of ['timeupdate','seeked','ended','pause']) track.addEventListener(event, draw, {signal});
    try {
      const response = await fetch('book-sentence-cues/' + encodeURIComponent(id) + '.json', {signal});
      if (!response.ok || signal.aborted) return;
      const payload = await response.json();
      if (signal.aborted) return;
      const paragraphs = [...column.querySelectorAll(':scope > p')];
      current.cues = payload.cues.flatMap(cue => {
        const paragraph = paragraphs[cue.p];
        if (!paragraph || paragraph.textContent.slice(cue.start, cue.end).trim() !== cue.text) return [];
        return [{...cue, paragraph, range: rangeFor(paragraph, cue)}];
      });
      if (current.cues.length) document.body.classList.add('sentence-playback');
      draw();
    } catch (error) {
      if (error.name !== 'AbortError') console.error(error);
    }
  }

  document.addEventListener('click', event => {
    if (!binding?.column?.contains(event.target) || event.target.closest('a, button') ||
        window.getSelection()?.toString()) return;
    const paragraph = event.target.closest('p');
    if (!paragraph) return;
    const caret = document.caretPositionFromPoint?.(event.clientX,event.clientY)
      ?? document.caretRangeFromPoint?.(event.clientX,event.clientY);
    const node = caret?.offsetNode ?? caret?.startContainer;
    if (!node || !paragraph.contains(node)) return;
    const prefix = new Range();
    prefix.selectNodeContents(paragraph);
    prefix.setEnd(node, caret.offset ?? caret.startOffset);
    const offset = prefix.toString().length;
    const cue = binding.cues.find(cue => cue.paragraph === paragraph && cue.start <= offset && offset < cue.end)
      ?? binding.cues.find(cue => cue.paragraph === paragraph && cue.end === offset);
    if (!cue) return;
    event.stopPropagation();
    const {track,lang,seek,controller} = binding;
    track.defaultPlaybackRate = track.playbackRate = lang === 'en' ? 0.85 : 0.75;
    const jump = () => seek(Math.max(0,cue.time - 0.08));
    if (track.readyState < 1) {
      track.addEventListener("loadedmetadata", jump, {once: true, signal: controller.signal});
    }
    track.play().catch(() => {});
    if (track.readyState >= 1) jump();
  }, true);

  window.readerSentences = {bind};
})();
